/**
 * @Author: Randy
 * @Date:   2017-08-23 10:17:59
 * @Email:  mynameislxmax@outlook.com
 * @Filename: hello_getRandom.js
 * @Last modified by:   Randy
 * @Last modified time: 2017-08-23 10:20:14
 */

'use strict';



module.exports = function(){
  return Math.random();
}
